function xt = jan8_04(t,ck)
%  computes sum of sinusoidal terms of the form in (1.1)
%  x = sinsum(t,ck)
%
K =  length(ck);k = 1:K;
ck = ck(:)';t = t(:)';
xt = ck * sin(2*pi*k'*t) ;

plot(xt);

hold on;
stem(xt);


