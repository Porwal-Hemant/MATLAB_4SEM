t = 0:0.01:1;k=1:3;
xt = (1./k)*sin(2*pi*k'*t);
plot(xt);