n = 48 ; wn = 0.175 ;
B = fir1(n,wn);
freqz(B);
zplane(B);

