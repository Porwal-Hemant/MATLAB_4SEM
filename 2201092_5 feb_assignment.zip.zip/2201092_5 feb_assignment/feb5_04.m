f = [0 0.6 0.6 1]; % Frequency breakpoints
m = [1 1 0 0]; % Magnitude breakpoints
b = fir2(30,f,m); % Frequency sampling-based FIR filter design
[h,w] = freqz(b,1,128); % Frequency response of filter
plot(f,m,w/pi,abs(h))
legend('Ideal','fir2 Designed')
title('Comparison of Frequency Response Magnitudes')



