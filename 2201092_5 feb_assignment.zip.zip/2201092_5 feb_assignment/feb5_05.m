load chirp; % Load data (y and Fs) into workspace
y = y + 0.5*rand(size(y)); % Adding noise
f = [0 0.48 0.48 1]; % Frequency breakpoints
m = [0 0 1 1]; % Magnitude breakpoints
b = fir2(34,f,m); % FIR filter design
freqz(b,1,512); % Frequency response of filter
output = filtfilt(b,1,y); % Zero-phase digital filtering
figure; 
subplot(2,1,1); plot(y,'b'); title('Original Signal')
subplot(2,1,2); plot(output,'g'); title('Filtered Signal')

