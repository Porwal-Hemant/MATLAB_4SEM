load noisysignals x; % noisy waveform
%load noisysignals x;: Loads the noisy ECG waveform from the file noisysignals.mat

[b,a] = butter(12,0.2,'low'); % IIR filter design

y = filtfilt(b,a,x); % zero-phase filtering
y2 = filter(b,a,x); % conventional filtering
plot(x,'k-.'); grid on ; hold on
plot([y y2],'LineWidth',1.5);
legend('Noisy ECG','Zero-phase Filtering','Conventional Filtering')

 