load chirp;
% chirp.mat contains a signal y that has most of its power above fs/4 


y = y + 0.5*rand(size(y)); % Adding noise
b = fir1(34,0.48,'high',chebwin(35,30)); % FIR filter design
freqz(b,1,512); % Frequency response of filter
output = filtfilt(b,1,y); % Zero-phase digital filtering
figure;
subplot(2,1,1); plot(y,'b'); title('Original Signal')
subplot(2,1,2); plot(output,'g'); title('Filtered Signal')

