
N = 48 ;
Wn = [0.35 0.65];
B = fir1(N, Wn,"high" );
freqz(B);
zplane(B);
