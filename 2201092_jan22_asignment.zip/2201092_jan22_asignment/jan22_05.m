 b = [0.0181, 0.0543, 0.0543, 0.0181]; % filter coefficient array b
 a = [1.0000, -1.7600, 1.1829, -0.2781]; % filter coefficient array a
 m = 0:length(b)-1; l = 0:length(a)-1; % index arrays m and l
 K = 500; k = 0:1:K; % index array k for frequencies
 w = pi*k/K; % [0, pi] axis divided into 501 points.
 num = b * exp(-j*m'*w); % Numerator calculations
 den = a * exp(-j*l'*w); % Denominator calculations
 H = num ./ den; % Frequency response
 magH = abs(H); angH = angle(H); % mag and phase responses

  subplot(2,1,1); plot(w/pi,magH); grid; axis([0,1,0,1])
 xlabel('frequency in pi units'); ylabel('|H|');
 title('Magnitude Response');
 subplot(2,1,2); plot(w/pi,angH/pi); grid
 xlabel('frequency in pi units'); ylabel('Phase in pi Radians');
 title('Phase Response');

% Given coefficients
b = [0.0181, 0.0543, 0.0543, 0.0181];
a = [1, -1.7, 1.1829, -0.2781];

% Frequency response
freq = 0:0.01:pi;
h = freqz(b, a, freq);

% Plot magnitude response
figure;
subplot(2, 1, 1);
plot(freq/pi, 20*log10(abs(h)));
title('Magnitude Response');
xlabel('Normalized Frequency (\pi radians/sample)');
ylabel('Magnitude (dB)');
grid on;

% Plot phase response
subplot(2, 1, 2);
plot(freq/pi, angle(h)*180/pi);
title('Phase Response');
xlabel('Normalized Frequency (\pi radians/sample)');
ylabel('Phase (degrees)');
grid on;

% Check LPF nature with sinusoidal inputs
fs = 1000; % Sampling frequency
t = 0:1/fs:1;

% Sinusoidal inputs below and above cutoff frequency
f_low = 50; % Frequency below cutoff
f_high = 200; % Frequency above cutoff
x_low = sin(2*pi*f_low*t);
x_high = sin(2*pi*f_high*t);

% Sum of sinusoidal inputs
x_sum = x_low + x_high;

% Filter the signals
y_low = filter(b, a, x_low);
y_high = filter(b, a, x_high);
y_sum = filter(b, a, x_sum);

% Plot the results
figure;
subplot(3, 1, 1);
plot(t, x_low, t, y_low);
title('Input and Output (Sinusoidal Below Cutoff)');
legend('Input', 'Output');
xlabel('Time (s)');
grid on;

subplot(3, 1, 2);
plot(t, x_high, t, y_high);
title('Input and Output (Sinusoidal Above Cutoff)');
legend('Input', 'Output');
xlabel('Time (s)');
grid on;

subplot(3, 1, 3);
plot(t, x_sum, t, y_sum);
title('Input and Output (Sum of Sinusoidals)');
legend('Input', 'Output');
xlabel('Time (s)');
grid on;

% Check LPF nature with sinusoidal audio inputs
fs_audio = 44100; % Audio sampling frequency
t_audio = 0:1/fs_audio:2;

% Audio sinusoidal inputs below and above cutoff frequency
f_audio_low = 1000; % Frequency below cutoff
f_audio_high = 5000; % Frequency above cutoff
x_audio_low = sin(2*pi*f_audio_low*t_audio);
x_audio_high = sin(2*pi*f_audio_high*t_audio);

% Sum of audio sinusoidal inputs
x_audio_sum = x_audio_low + x_audio_high;

% Filter the audio signals
y_audio_low = filter(b, a, x_audio_low);
y_audio_high = filter(b, a, x_audio_high);
y_audio_sum = filter(b, a, x_audio_sum);

% Plot the results for audio signals
figure;
subplot(3, 1, 1);
plot(t_audio, x_audio_low, t_audio, y_audio_low);
title('Audio Input and Output (Below Cutoff)');
legend('Input', 'Output');
xlabel('Time (s)');
grid on;

subplot(3, 1, 2);
plot(t_audio, x_audio_high, t_audio, y_audio_high);
title('Audio Input and Output (Above Cutoff)');
legend('Input', 'Output');
xlabel('Time (s)');
grid on;

subplot(3, 1, 3);
plot(t_audio, x_audio_sum, t_audio, y_audio_sum);
title('Audio Input and Output (Sum of Sinusoidals)');
legend('Input', 'Output');
xlabel('Time (s)');
grid on;





