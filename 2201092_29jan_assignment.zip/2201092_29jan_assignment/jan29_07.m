[sos ,G] = tf2sos(b,a) ;

disp(sos);
disp(G);
