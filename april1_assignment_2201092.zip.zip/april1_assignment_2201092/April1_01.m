
function X = April1_01(x)
    N = length(x);
    
    % Check if N is a power of 2
    if log2(N) ~= nextpow2(N)
        error('Input length must be a power of 2');
    end
    
    if N == 1
        X = x; % Base case of recursion
    else   
        % let us have recursive calls from here 
        X_even = April1_01(x(1:2:N)); % Recursive call for even-indexed elements
        X_odd = April1_01(x(2:2:N));  % Recursive call for odd-indexed elements
        
        % Compute twiddle factors
        twiddle_factors = exp(-2i*pi*(0:N/2-1)/N);
        
        % Perform butterfly operations
        X = [X_even + twiddle_factors .* X_odd, X_even - twiddle_factors .* X_odd];
    end
end

