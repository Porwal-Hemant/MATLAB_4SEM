% Constants
f = 0.125;
n = 1:200;      % 200 samples 
xn = 2*sin(2*pi*f*n) + sin(4*pi*f*n);    % sum of 2 sinusoids 

% Plot the sequence
figure;
stem(n, xn);    % stem command for plotting sequence 
xlabel('n');    
ylabel('x[n]');
title('Sequence x[n]');
hold on  ; 
D = fft(xn(1:100)) ;    % taking fft of the sinusoidal signal 

y = abs(fftshift(D));

figure ;
stem(y);
title('Magnitude of 100-point DFT coefficients');


