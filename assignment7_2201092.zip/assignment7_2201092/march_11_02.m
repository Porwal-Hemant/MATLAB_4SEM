
% Spectral resolution refers to the ability of a spectrum to distinguish between closely spaced frequencies. 
% It is defined as the smallest frequency difference that can be resolved by a spectrum analysis method.

% observation -> 
% spectral resolution is equal to 1 / number of sample spaces 
% hence spectral resolution of 100 point dft coefficient is more clear
% than 200 point dft coefficient 

% Constants
f = 0.125;
n = 1:200;      % 200 samples 
xn = 2*sin(2*pi*f*n) + sin(4*pi*f*n);    % sum of 2 sinusoids 

% Plot the sequence
figure;
stem(n, xn);    % stem command for plotting sequence 
xlabel('n');    
ylabel('x[n]');
title('Sequence x[n]');

% Perform 100-point DFT of the first 100 samples
X_new = fft(xn(1:100), 200);  % Compute 200-point DFT by zero-padding
X_new_magnitude = abs(fftshift(X_new));  % Magnitude of DFT
n_values = 1:200;  % Frequency indices

% Plot the magnitude of the 200-point DFT
figure;
stem(n_values, X_new_magnitude);
xlabel('k');
ylabel('|X[k]|');
title('Magnitude of 200-point DFT coefficients with 100 zeros padded at the end');

% Locate the spectral peaks
[peak_values, peak_indices] = findpeaks(X_new_magnitude, 'MinPeakHeight', mean(X_new_magnitude));

% Plot the spectral peaks on the magnitude plot
hold on;
stem(peak_indices, peak_values, 'r', 'LineWidth', 1.5);
hold off;

% Display the indices and values of spectral peaks
disp('Indices of Spectral Peaks:');
disp(peak_indices);
disp('Values of Spectral Peaks:');
disp(peak_values);


