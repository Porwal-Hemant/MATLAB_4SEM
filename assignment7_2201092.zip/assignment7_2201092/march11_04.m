% Create a 16-point input sequence
%x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16];  % 16 length sequence 
%N = length(x);  % Length of the sequence    % N = 16 
% Frequency index

function temp = march11_04(x , N)
k = 0:N-1;
temp = zeros(1, N);

for m = 1:N
    for n = 1:N
        temp(m) = temp(m) + x(n) * exp(-1i*2*pi*(m-1)*(n-1)/N);
    end
end

% Calculate the magnitude of DFT
XFor_mag = abs(temp);

subplot(2, 1, 1);
stem(k, XFor_mag);
xlabel('k');
ylabel('|XFor[k]|');
title('Magnitude of 16-point DFT without fft');





% Calculate the phase of DFT
%XFor_phase = angle(temp);

% Plot the magnitude and phase of the DFT