% Define the signal
x = [1 2 3 4 5]; % Sample signal
N = length(x); % Length of signal

% Compute DFT of the signal
X = fft(x);

% Calculate sum of squares of magnitudes in time domain
sum_time_domain = sum(abs(x).^2);

% Calculate sum of squares of magnitudes in frequency domain
sum_freq_domain = 1/N * sum(abs(X).^2);

% Verify Parseval's Theorem
if abs(sum_time_domain - sum_freq_domain) < eps
    disp('Parseval''s Theorem Verified');
else
    disp('Parseval''s Theorem Not Verified');
end
