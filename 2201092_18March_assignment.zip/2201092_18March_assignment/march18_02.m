% Step 1: Generate the input signal x[n]
x = randn(1, 20);

% Step 2: Create the length-4 impulse response of the filter h[n]
h = [-1, 0, 0.3, 2];

% Step 3: Perform linear convolution using conv()
y_linear = conv(x, h);

% Step 4: Perform filtering using overlap-and-add method
Lx = length(x); % Length of input signal
Lh = length(h); % Length of filter impulse response
N = 2^nextpow2(Lx + Lh - 1); % Next power of 2 greater than or equal to (Lx + Lh - 1)

% Pad x and h to length N
x_padded = [x, zeros(1, N - Lx)];
h_padded = [h, zeros(1, N - Lh)];

% Perform FFTs of x and h
X = fft(x_padded);
H = fft(h_padded);

% Perform element-wise multiplication in frequency domain
Y = X .* H;

% Perform inverse FFT to obtain filtered output
y_overlap_add = ifft(Y);

% Trim excess values from the output
y_overlap_add = y_overlap_add(1:Lx + Lh - 1);

% Step 5: Compare the two outputs
disp('Output of linear convolution:');
disp(y_linear);
disp('Output of Overlap-and-Add method:');
disp(y_overlap_add);
