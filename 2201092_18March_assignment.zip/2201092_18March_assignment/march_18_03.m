% Generate 8 samples of x[n] using a random Gaussian distribution
x = randn(1, 8);

% Compute the 8-point DFT of x[n] using the ifft() function
X_ifft = ifft(x, 8);

% Compute the 8-point DFT of x[n] using the fft() function for verification
X_fft = fft(x, 8);

% Display the results
disp('Result of 8-point DFT using ifft():');
disp(X_ifft);
disp('Result of 8-point DFT using fft() for verification:');
disp(X_fft);
