% Define the signal
x = [1 2 3 4 5]; % Sample signal
N = length(x); % Length of signal

% Compute DFT of the original signal
X = fft(x);

% Circularly shift the signal by k positions
k = 2; % Shift amount
x_shifted = circshift(x, k);

% Compute DFT of the shifted signal
X_shifted = fft(x_shifted);

% Verify the circular shift property: X_shifted = X * exp(-j*2*pi*k/N)
expected_X_shifted = X .* exp(-1j*2*pi*k/N*(0:N-1));

% Check if both sides are approximately equal
tolerance = 1e-10; % Tolerance for numerical errors
if max(abs(X_shifted - expected_X_shifted)) < tolerance
    disp('Circular Shift Property Verified');
else
    disp('Circular Shift Property Not Verified');
end
