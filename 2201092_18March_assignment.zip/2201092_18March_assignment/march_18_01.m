x = randn(1, 20);
h = [-1 0 0.3 2];
y_linear = conv(x, h);

Ls = length(x); % Length of input signal             length =  20 
M = length(h); % Length of filter impulse response   m = 4 
%N = 2^nextpow2(Ls + M - 1); % Next power of 2 greater than or equal to (Ls + M - 1)
N= 8 ;                % length of filter 
L = N - M + 1;        % 

h_padded = [h, zeros(1, N - M)]; % Pad h to match N
num_segments = ceil(Ls / L);

y_overlap_save = zeros(1, Ls + M - 1);

for i = 1:num_segments
    start_idx = (i - 1) * L + 1;
    end_idx = min(start_idx + L - 1, Ls); 
    
    % Extract segment
    x_segment = x(start_idx:end_idx);
    
    % Pad segment with zeros
    x_segment_padded = [x_segment, zeros(1, N - length(x_segment))];
    
   % x_segment_padded = [ zeros(1, N - length(x_segment)) , x_segment];
    % Perform convolution in frequency domain
    X_segment = fft(x_segment_padded);
    H_segment = fft(h_padded);
    Y_segment = ifft(X_segment .* H_segment);
    
    % Update output
    end_idx_update = min(start_idx + N - 1, Ls + M - 1); % Adjust for end of y_overlap_save
    y_overlap_save(start_idx:end_idx_update) = y_overlap_save(start_idx:end_idx_update) + Y_segment(1:end_idx_update-start_idx+1);
end

% Trim excess values from the output
y_overlap_save = y_overlap_save(1:Ls + M - 1);

disp('Output of linear convolution:');
disp(y_linear);
disp('Output of Overlap-and-Save method:');
disp(y_overlap_save);


