load handel; % signal is in y and sampling frequency in FS 
sound(y,Fs); pause(10); % play the original sound
alpha = 0.9; D=4196; % echo parameters
b=[1,zeros(1,D),alpha]; % filter parameters
x=filter(b,1,y);% generate sound plus its echo
sound(x,Fs);% play sound with echo
w = filter(1,b,x);
sound(w,fs)

% writing code by myself from here 

% n = 5 ;  
% k = 0:1:n-1 ;


