load handel; % signal is in y and sampling frequency in FS 
sound(y,Fs); pause(10); % play the original sound
alpha = 0.9; 
D=[1 2 3];
b=[1,zeros(1,D(1)),alpha , zeros(1,D(2)) ,alpha^2, zeros(1,D(3)) ,alpha^3]  ; % filter parameters
x=filter(b,1,y);% generate sound plus its echo
sound(x,Fs);% play sound with echo
w = filter(1,b,x);
sound(w,fs)

